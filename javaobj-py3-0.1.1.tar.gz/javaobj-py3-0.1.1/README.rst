python-javaobj
##############

This project is a fork of python-javaobj by Volodymyr Buell, from
http://code.google.com/p/python-javaobj/

From the original project site:

   Provides functions for reading and writing (writing is WIP currently)
   Java objects serialized or will be deserialized by ObjectOutputStream.
   This form of object representation is a standard data interchange format
   in Java world. javaobj module exposes an API familiar to users of the
   standard library marshal, pickle and json modules.


This fork intends to work both on Python 2.7 and Python 3.


TODO
****

* Correct tests (Swing, ...)
