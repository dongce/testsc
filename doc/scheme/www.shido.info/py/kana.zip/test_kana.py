#!python
#coding:utf8

import kana

def pprint(*ls):
    print(*ls, sep='\n', end='\n\n')

if __name__=='__main__':
    for s in ['てんはひとのうえにひとをつくらずひとのしたにひとをつくらず', \
              'ほんじつはせいてんなれどもなみたかし', \
              'わがはいはねこである', \
             ]:
        pprint(s, kana.jz(s), kana.jh(s))

    for s in ['テンハヒトノウエニヒトヲツクラズヒトノシタニヒトヲツクラズ', \
              'ホンジツハセイテンナレドモナミタカシ', \
              'ワガハイハネコデアル', \
             ]:
        pprint(s,  kana.zh(s), kana.zj(s))

    for s in ['ﾃﾝﾊﾋﾄﾉｳｴﾆﾋﾄｦﾂｸﾗｽﾞﾋﾄﾉｼﾀﾆﾋﾄｦﾂｸﾗｽﾞ', \
              'ﾎﾝｼﾞﾂﾊｾｲﾃﾝﾅﾚﾄﾞﾓﾅﾐﾀｶｼ', \
              'ﾜｶﾞﾊｲﾊﾈｺﾃﾞｱﾙ', \
              ]:
        pprint(s, kana.hz(s), kana.hj(s))

        