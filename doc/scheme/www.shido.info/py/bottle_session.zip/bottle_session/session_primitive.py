import os, sqlite3
import bottle as btl
from beaker.middleware import SessionMiddleware

DEBUG=True
DB_FILE=os.path.join('db', 'db.sqlite3')
SALT=b'a_random_string to make stored passwords secure'

session_opts = {
    'session.type': 'file',
    'session.cookie_expires': 1000,
    'session.data_dir': './data',
    'session.auto': True
}
app = SessionMiddleware(btl.app(), session_opts)


def session_set(k,v):
    '''setting the value of k as v in the session'''
    s = btl.request.environ['beaker.session']
    s[k]=v
    s.save()


def session_get(k, delete=False):
    '''getting value of k from the session'''
    s = btl.request.environ['beaker.session']
    v=s[k] if k in s else ''
    if delete and k in s:
        del s[k]
    return v


def form_get(k):
    '''getting the value of k from the form'''
    return btl.request.forms.get(k)


def hash_pw(uid, pw):
    '''calculate the hash value for uid and password'''
    a=hashlib.sha1()
    a.update(uid.encode('utf8')+SALT+pw.encode('utf8'))
    return a.hexdigest()


def get_role(uid, pw):
    db=sqlite3.connect(DB_FILE)
    try:
        db.execute('select role from users where uid=? and pw=?', 
                   (uid, hash_pw(uid, pw))).fetchone()
        return r[0] if r is not None else None
    finally:
        db.close()


def users():
    db=sqlite3.connect(DB_FILE)
    try:
        return db.execute('select uid, role from users').fetchall()
    finally:
        db.close()



@btl.get('/login')
@btl.view('login')
def login_form():
    return {'message':session_get('message', True)}


@btl.post('/login')
@btl.view('login')
def login():
    uid=form_get('uid')
    pw=form_get('pw')
    role=get_role(uid, pw)
    if role is not None:
        session_set('uid', uid)
        session_set('role', role)
        session_set('message', 'こんにちは、{} さん'.format(uid))
        return btl.redirect('/')
    else:
        return {'message':'ID か Password が間違っています。'}


@btl.route('/logout')
def logout():
    s = btl.request.environ['beaker.session']
    s.delete()
    return btl.redirect('/login')
    
    

@btl.route('/')
@btl.view('index')
def index():
    '''TOP page'''
    role=session_get('role')
    if role is not None:
        return {'message':session_get('message', True),
                'role':role}
    else:
        session_set('message', 'ログインが必要です')
        return btl.redirect('/login')


@btl.route('/user')
@btl.view('users')
def users():
    '''List of users'''
    role=ut.session_get('role')
    if role=='admin':
        return {'users':users()}
    else:
        session_set('message', 'admin でログインが必要です')
        return btl.redirect('/login')


if __name__=='__main__':
    btl.run(app=app, debug=DEBUG, reloader=DEBUG)