#!python3

'''
Life game tkinter version.

Usage:
mouse click: toggle a cell, living<->dead (reset state only)
space: to start, stop, and reset
l    : load a set of living cells from a file (reset state only)
s    : save the set of living cells to a file (reset state only)
c    : clear, there are no living cells  after this command (reset state only)
'''

import tkinter as tk
from tkinter.filedialog import askopenfile, asksaveasfile
import pickle

import life

def in_range(c,min_,max_):
    '''check if the cell c is in the square specified by min_ and max_'''
    return all(min_<=z<=max_ for z in (c.x,c.y))


class Board (tk.Canvas):
    '''The board where cells are on.'''

    SIZE=800                  # board size in pixel
    CELL_SIZE=8               # cell size in pixel
    B_SIZE=SIZE//CELL_SIZE    # number of cells in each side
    MARGIN=10                 # the width of the band outside of the board, where lives are still living
    RESET,START,STOP=0,1,2    # cyclic states
    TAG_FORMAT='{}.{}'           # format of tag
    SLEEP=250                 # in ms

    def __init__(self, master=None):
        '''create board, bind methods to keys'''
        tk.Canvas.__init__(self, master, bg='white', width=self.SIZE, height=self.SIZE)
        self.master.title('Life Game')
        self.livings=set()  # the set of living cells
        self.state=self.RESET # the state
        self.bind('<1>', self.toggle)
        for k, a in [('<space>','proceed'),
                     ('<KeyPress-l>','load'),
                     ('<KeyPress-s>','save'),
                     ('<KeyPress-c>','clear')]:
            self.master.bind(k, getattr(self,a))
        self.pack()

    def proceed(self, e):
        '''proceed the state'''
        self.state=(self.state+1) % 3
        if self.state==self.START:
            self.play(self.livings)
        elif self.state==self.RESET:
            self.show_lives(self.livings)

    def show_each(self, x, y):
        '''draw a black square'''
        self.create_rectangle( *[z*self.CELL_SIZE for z in (x,y,x+1,y+1)],
                                fill='black', tags=self.TAG_FORMAT.format(x,y))

    def show_lives(self, cs):
        '''show living cells'''
        self.delete(tk.ALL)
        for c in cs:
            if in_range(c, 0, self.B_SIZE):
                self.show_each(c.x, c.y)

    def toggle(self,e):
        '''living<->dead'''
        if self.state == self.RESET:
            c=life.Cell(e.x//self.CELL_SIZE, e.y//self.CELL_SIZE)
            if c in self.livings:
                self.livings.remove(c)
                self.delete(self.TAG_FORMAT.format(c.x,c.y))
            else:
                self.livings.add(c)
                self.show_each(c.x,c.y)

    def play(self, cs):
        '''play life game'''

        def keep_watching(_c):
            return in_range(_c,-self.MARGIN, self.B_SIZE+self.MARGIN)

        self.show_lives(cs)
        if self.state==self.START:
            self.after(self.SLEEP, lambda : self.play(life.generate(cs, keep_watching)))



    def load(self,_e):
        '''load saved cells'''
        if self.state == self.RESET:
            with askopenfile(mode='rb') as f:
                self.livings=pickle.load(f)
            self.show_lives(self.livings)

    def save(self,_e):
        '''save cells'''
        if self.state == self.RESET:
            with asksaveasfile(mode='wb') as f:
                pickle.dump(self.livings, f)

    def clear(self,_e):
        '''clear the board'''
        if self.state == self.RESET:
            self.delete(tk.ALL)
            self.livings.clear()


if __name__=='__main__':
    b=Board()
    b.mainloop()