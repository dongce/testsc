#!python
'''life game console virsion'''

from collections import namedtuple

Cell = namedtuple('Cell', 'x y')

def neighbors(c):
    '''return a set of adjacent cells to c'''
    return {Cell(c.x+dx, c.y+dy) for dx in (-1,0,1) for dy in (-1,0,1) if (dx,dy)!=(0,0)}


def survive(c,cs):
    '''see if the cell will survive in the next generation'''
    nadj=len(neighbors(c) & cs)
    return nadj==3 or (c in cs and nadj==2)


def include_neighbors(cs):
    '''return union of cs and the neighbors'''
    cs1=cs.copy()
    for c in cs:
        cs1.update(neighbors(c))
    return cs1


def generate(cs, f=lambda c:True):
    '''return the set of living cells in the  next generation, f is an additional constraint'''
    return { c for c in include_neighbors(cs) if survive(c,cs) and f(c) }


def play(cs, board_size=5, n_rep=5):
    '''console version of life game'''
    def show(_cs):
        for y in range(-board_size, board_size):
            print( ''.join('*' if Cell(x,y) in _cs else ' ' for x in range(-board_size, board_size)))

    def _iter(n, _cs):
        show(_cs)
        if n<n_rep:
            _iter(n+1, generate(_cs))

    _iter(0, cs)


if __name__=='__main__':
    play({Cell(-1,0), Cell(0,0),Cell(1,0)})